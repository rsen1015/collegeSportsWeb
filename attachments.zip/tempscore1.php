
<html>
<head>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<h1>Feed Score</h1>
</head>
<body>
    <form name="score" action="tempsc2.php" method="post">

    Balls Bowled: <input type="number" name="id" value=1><br>

    Runs scored: <input type="number" name="runs"><br>

    out or not : <input type="number" name="wick"><br>
    
    <input type="submit" name="submit" value="Add Score" style="text-align: center;font-size:18px;" class="btn btn-info">
    </form> 
 </body>
 </html>


 


